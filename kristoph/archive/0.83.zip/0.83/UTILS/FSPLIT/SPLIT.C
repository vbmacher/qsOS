/*
 * FSPLIT.C
 *
 * (c) Copyright 2001-2002, P. Jakubco ml.
 *
 *
 */

#include "fio.h"
#include "exestruc.h"
void printf(const char *format, ...);

void WriteHeader(int ifh);
void WriteData(int ifh);

char *SrcFile;
static char *DestFile = "splt0000.img";

static char Buffer[32768];

void main()
{
	int ifh;
	TExeHeader ExeHeader;
	char *SrcFile;

	printf("\nAtheros File Splitter v1.00\n(c) Copyright 2001-2002, P. Jakubco ml.\n");
	printf("\nEnter source file name:");
        gets(SrcFile);
	printf("\nFirst destination file name: splt0000.img");
	printf("\nSplitting...");

	ifh = open(SrcFile,O_RDWR);
//	WriteHeader(ifh);
	WriteData(ifh);
	close(ifh);

}

void WriteHeader(int ifh)
{
	TExeHeader ExeHeader;
	int ofh;
	unsigned short Count;

	ofh = creat(DestFile);
	read(ifh,&ExeHeader,sizeof (ExeHeader));
	write(ofh,&ExeHeader,sizeof (ExeHeader));
	Count = ExeHeader.HeaderSize * 16 - sizeof (TExeHeader);
	read(ifh,Buffer,Count);
	write(ofh,Buffer,Count);
	close(ofh);
	++DestFile[7];
}

void WriteData(int ifh)
{
	unsigned short Bytes;
	int ofh;

	while ((Bytes = read(ifh,Buffer,32768)) != 0) {
		printf("\nCreating file: %s", DestFile);

		ofh = creat(DestFile);
		write(ofh,Buffer,Bytes);
		close(ofh);
		++DestFile[7];
	}
}
