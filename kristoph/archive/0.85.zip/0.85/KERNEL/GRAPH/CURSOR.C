/*
 * CURSOR.CPP
 *
 * (c) Copyright 2002, P. Jakubco ml.
 *
 */


#include <dcx.h>
#include <vpgraph.h>
//#include <mem.h>
#include <pmlib.h>
#include <grmem.h>

#define CURSOR_WIDTH 11
#define CURSOR_HEIGHT 19


int CursorX = 0;
int CursorY = 0;
int CursorVisible = 0;

void DrawCursor(void)
{
	int Pixel;

	if (!CursorVisible)
		return;
	VPGetImage(CursorX,CursorY,CURSOR_WIDTH,CURSOR_HEIGHT,CursorBGnd);
	PMMemCopy(CursorFGnd,CursorBGnd,CURSOR_WIDTH * CURSOR_HEIGHT);
	CreateCursor(CursorFGnd);
	VPPutImage(CursorX,CursorY,CURSOR_WIDTH,CURSOR_HEIGHT,CursorFGnd);

}

void ClearCursor(void)
{
	if (!CursorVisible)
		return;
	VPPutImage(CursorX,CursorY,CURSOR_WIDTH,CURSOR_HEIGHT,CursorBGnd);
}


